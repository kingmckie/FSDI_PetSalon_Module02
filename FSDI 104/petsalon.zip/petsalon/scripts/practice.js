/*
const dog1 ={
    name:"Rufus",
    color: "black",
    size: "medium",
    age:4,
};

const dog2 = new DOMStringMap("Rufus", "black", "medium", 4);*/

console.log("practice");

let student = {
    name:"Mark",
    age:39,
    grades:[10,9,8,7],
    address: {
        country: "united states"
        state: "california"
        city: "san francisco"
    },
}   

console.log(student);


let student2 = {
    name: "Mickie",
    age:39,
    grades: [10,10,10,10],
    address: {
        country: "Mexico"
        state: "Tiepez"
        city: "Leon"
    },
            
        {

        consol3/log(student, student2);
        <div class="student">
        <P>Name: ${student.name}</P>
        <p>Age: ${student.age}</p>
        <p>Country: ${student}</p>
        },